#include "list.h"

int testCyclic(LinkedList * ls);
LinkedList * reverseList(LinkedList * ls);
