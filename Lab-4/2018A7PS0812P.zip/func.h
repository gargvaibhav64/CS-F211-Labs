

void * myalloc(size_t size);
void myfree(void * ptr, int size);

LinkedList * createList(int n);
LinkedList * createCycle(LinkedList * ls);
void printList(LinkedList * temp);